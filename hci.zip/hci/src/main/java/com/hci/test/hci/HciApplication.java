package com.hci.test.hci;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HciApplication {

	public static void main(String[] args) {
		SpringApplication.run(HciApplication.class, args);
	}

}
